// Subtle hover animation effect
document.querySelectorAll('.product').forEach(product => {
    product.addEventListener('mouseenter', () => {
      product.style.boxShadow = '0 20px 40px rgba(0, 0, 0, 0.1)';
    });
    product.addEventListener('mouseleave', () => {
      product.style.boxShadow = '0 10px 20px rgba(0, 0, 0, 0.05)';
    });
  });

  document.addEventListener("DOMContentLoaded", () => {
    const cartButtons = document.querySelectorAll(".btn-cart");
    const toast = document.getElementById("toast");
  
    // Load existing cart or initialize
    let cartItems = JSON.parse(localStorage.getItem("cartItems")) || [];
  
    cartButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        const product = btn.closest(".product");
        const title = product.querySelector("h3").textContent.trim();
        const price = product.querySelector(".price").textContent.trim();
  
        // Create cart item object
        const item = { title, price };
  
        // Add to cartItems array
        cartItems.push(item);
        localStorage.setItem("cartItems", JSON.stringify(cartItems));
  
        // Show toast
        toast.textContent = `"${title}" added to cart`;
        toast.classList.add("show");
        setTimeout(() => {
          toast.classList.remove("show");
        }, 2000);
      });
    });
  });
   
  document.addEventListener("DOMContentLoaded", () => {
    const cartButtons = document.querySelectorAll(".btn-cart");
    const toast = document.getElementById("toast");
  
    cartButtons.forEach((btn) => {
      btn.addEventListener("click", () => {
        toast.textContent = "Added to Cart";
        toast.classList.add("show");
  
        setTimeout(() => {
          toast.classList.remove("show");
        }, 2000);
      });
    });
  });
  