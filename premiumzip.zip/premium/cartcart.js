let cart = JSON.parse(localStorage.getItem("cartItems")) || [];
const cartList = document.getElementById("cart-list");
const totalEl = document.getElementById("total");
const payBtn = document.getElementById("pay-now");

function renderCart() {
  cartList.innerHTML = "";
  let total = 0;

  if (cart.length === 0) {
    cartList.innerHTML = "<li>Your cart is empty.</li>";
    totalEl.textContent = "";
    payBtn.style.display = "none";
    return;
  }

  cart.forEach((item, index) => {
    const li = document.createElement("li");
    li.classList.add("cart-item");
    li.innerHTML = `
      <span>${item.title}</span>
      <span>${item.price}</span>
      <button class="delete-btn" data-index="${index}">Delete</button>
    `;
    cartList.appendChild(li); //DOM runtime

    const price = parseFloat(item.price.replace(/[^0-9.]/g, ""));
    total += price;
  });

  totalEl.textContent = `Total: $${total.toFixed(2)}`;
  payBtn.style.display = "inline-block";
}

cartList.addEventListener("click", (e) => {
  if (e.target.classList.contains("delete-btn")) {
    const index = e.target.getAttribute("data-index");
    cart.splice(index, 1);
    localStorage.setItem("cartItems", JSON.stringify(cart));
    renderCart();
  }
});

payBtn.addEventListener("click", () => {
  alert("Proceeding to payment...");
  localStorage.removeItem("cartItems");
  window.location.reload();
});

renderCart();

console.log("First item in cart list:", cartList.firstElementChild); //dom tree navigation


document.addEventListener("keydown", (e) => { //key-based event
  if (e.key === "Delete" && cart.length > 0) {
    if (confirm("Are you sure you want to clear the cart?")) {
      cart = [];
      localStorage.removeItem("cartItems");
      renderCart();
    }
  }
});
