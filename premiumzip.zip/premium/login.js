const form = document.getElementById("auth-form");
const formTitle = document.getElementById("form-title");
const toggleText = document.getElementById("toggle-text");
const toggleLink = document.getElementById("toggle-link");
let isLogin = true;
form.addEventListener("submit", (e) => {
    e.preventDefault();
  
    // Simulated login/signup process
    alert(isLogin ? "Logging in..." : "Signing up...");
  
    // Redirect to home page (lux.html)
    window.location.href = "lux.html";
  });
   
toggleLink.addEventListener("click", (e) => {
  e.preventDefault();
  isLogin = !isLogin;

  formTitle.textContent = isLogin ? "Login" : "Sign Up";
  toggleText.innerHTML = isLogin
    ? `Don't have an account? <a href="#" id="toggle-link">Sign Up</a>`
    : `Already have an account? <a href="#" id="toggle-link">Login</a>`;

  document.querySelector("button").textContent = isLogin ? "Login" : "Sign Up";
});

// You can add form submission handling logic here
form.addEventListener("submit", (e) => {
  e.preventDefault();
  alert(isLogin ? "Logging in..." : "Signing up...");
});
